package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.ArrayList;

public class DataManager extends SQLiteOpenHelper {

    public DataManager(Context context) {
        super(context, "WeightDB", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE weights(username TEXT, weight TEXT, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For dev testing, just drop and recreate
        db.execSQL("DROP TABLE IF EXISTS weights");
        onCreate(db);
    }

    public void insertWeight(String username, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("weight", weight);
        cv.put("date", date);
        db.insert("weights", null, cv);
    }

    public ArrayList<String> getAllWeights(String username) {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT weight, date FROM weights WHERE username = ? ORDER BY date DESC", new String[]{username});
        if (cursor.moveToFirst()) {
            do {
                String weight = cursor.getString(0);
                String date = cursor.getString(1);
                list.add(weight + " kg\n" + date);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }
}