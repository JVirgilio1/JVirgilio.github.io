package com.example.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_REQUEST_CODE = 100;
    private static final int IMAGE_CAPTURE_REQUEST_CODE = 101;

    private Button btnTakeMealPicture;
    private ArrayList<Bitmap> imageList;
    private ImageAdapter imageAdapter;

    private Uri photoURI;
    private File photoFile;

    DataManager dbHelper;
    GridView gridView;
    EditText weightInput;
    Button addButton;
    String username;
    final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        dbHelper = new DataManager(this);
        username = getIntent().getStringExtra("USERNAME");

        weightInput = findViewById(R.id.mealInput);
        addButton = findViewById(R.id.addButton);
        gridView = findViewById(R.id.gridView);

        loadWeights();

        addButton.setOnClickListener(view -> {
            String weight = weightInput.getText().toString().trim();
            if (!weight.isEmpty()) {
                String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                dbHelper.insertWeight(username, weight, date);
                loadWeights();
                askSmsPermissionAndSend("New weight logged: " + weight + " kg on " + date);
                weightInput.setText("");
            }
        });
    }

    private void loadWeights() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, dbHelper.getAllWeights(username));
        gridView.setAdapter(adapter);
    }

    private void askSmsPermissionAndSend(String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSMS(message);
        }
    }

    private void sendSMS(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null, message, null, null);
            // temporary number, can be changed
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMS("SMS permission granted.");
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}